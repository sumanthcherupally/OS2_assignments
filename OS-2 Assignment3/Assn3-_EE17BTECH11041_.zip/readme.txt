Execute the file using std=c++11 or above.
g++ -std=c++11 -pthread -o sem prod_cons-locks-\<EE17BTECH11041\>.cpp
g++ -std=c++11 -pthread -o lock prod_cons-locks-\<EE17BTECH11041\>.cpp 

