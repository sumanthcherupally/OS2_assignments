Execute the program using c++11 or above
$ g++ -std=c++11 -pthread dphil-EE17BTECH11041.cpp -o phil