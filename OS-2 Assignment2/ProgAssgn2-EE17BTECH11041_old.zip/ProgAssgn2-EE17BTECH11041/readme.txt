Run the program files with c++11 or above. i.e by using $ g++ -std=c++11 file.cpp OR $ g++-6 file.cpp
Run the output files normally.
Then the required log files will be generated.
Do not open the log files untill the execution of the program otherwise the threads will lose synchronization.
