Execute the codes with g++-6 or using std11 and above
