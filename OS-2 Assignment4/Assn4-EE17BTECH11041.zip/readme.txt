Run the code files using -std=c++11 or above
g++ -std=c++11 -pthread -o rw rw-EE17BTECH11041.cpp
g++ -std=c++11 -pthread -o frw frw-EE17BTECH11041.cpp